package com.rab.rumahku

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
